pkg install python2 -y
pkg install python3 -y
pkg install python-pip
pkg install curl -y
pkg install termux-api -y
pip2 install mime
pip2 install colorama
pip2 install requests
pip2 install bs4

